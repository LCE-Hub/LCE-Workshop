function main()

----------------------------------------------------------------------------------------------------- BLOCKS ----------------------------------------------------------------------------------------------------------------
    local lucidBlockId = registerBlock
        ("lucidBlock", "Lucid Block", "res/lucid_block.png",
            BlockDefinition.new
            ({
                hardness = 2.0,
                resistance = 10.0,
                tool = EBlockTool.None, --Actually, it's EBlockTool.None i think
                sound = "cloth"                 -- Turns out "wool" is not what its called, its called "cloth". This may or may not make the recipe show up.
            })
        )
    log("Pixel's Blocks: registered lucidBlock as id " .. tostring(lucidBlockId))

    -- Granite

    local graniteId = registerBlock
        ("granite", "Granite", "res/granite.png",
            BlockDefinition.new ({ hardness = 4.0, resistance = 10.0, tool = EBlockTool.Pickaxe, sound = "stone" })
        )
    log("Pixel's Blocks: registered granite as id " .. tostring(graniteId))

    local polishedGraniteId = registerBlock --this one will be tested to see what the default value for lightBlocking is
        ("polishedGranite", "Polished Granite", "res/polished_granite.png",
            BlockDefinition.new ({ hardness = 4.0, resistance = 10.0, tool = EBlockTool.Pickaxe, sound = "stone" })
        )
    log("Pixel's Blocks: registered polished granite as id " .. tostring(polishedGraniteId))
    
    local graniteBricksId = registerBlock
        ("graniteBricks", "Granite Bricks", "res/granite_bricks.png",
            BlockDefinition.new ({ hardness = 4.0, resistance = 10.0, tool = EBlockTool.Pickaxe, sound = "stone" })
        )
    log("Pixel's Blocks: registered granite bricks as id " .. tostring(graniteBricksId))

    local graniteSlabId = registerBlock
        ("graniteSlab", "Granite Slab", "res/polished_granite.png",
            BlockDefinition.new ({ shape = "slab", hardness = 4.0, resistance = 10.0, tool = EBlockTool.Pickaxe, sound = "stone" })
        )
    log("Pixel's Blocks: registered granite slab as id " .. tostring(graniteSlabId))

    local graniteStairsId = registerBlock
        ("graniteStairs", "Granite Stairs", "res/polished_granite.png",
            BlockDefinition.new ({ shape = "stairs", hardness = 4.0, resistance = 10.0, tool = EBlockTool.Pickaxe, sound = "stone" })
        )
    log("Pixel's Blocks: registered granite stairs as id " .. tostring(graniteStairsId))

    -- Limestone

    local limestoneId = registerBlock
        ("limestone", "Limestone", "res/limestone.png",
            BlockDefinition.new ({ hardness = 4.0, resistance = 10.0, tool = EBlockTool.Pickaxe, sound = "stone" })
        )
    log("Pixel's Blocks: registered limestone as id " .. tostring(limestoneId))

    local polishedLimestoneId = registerBlock
        ("polishedLimestone", "Polished Limestone", "res/polished_limestone.png",
            BlockDefinition.new ({ hardness = 4.0, resistance = 10.0, tool = EBlockTool.Pickaxe, sound = "stone" })
        )
    log("Pixel's Blocks: registered polished limestone as id " .. tostring(polishedLimestoneId))

    local limestoneBricksId = registerBlock
        ("limestoneBricks", "Limestone Bricks", "res/limestone_bricks.png",
            BlockDefinition.new ({ hardness = 4.0, resistance = 10.0, tool = EBlockTool.Pickaxe, sound = "stone" })
        )
    log("Pixel's Blocks: registered limestone bricks as id " .. tostring(limestoneBricksId))

    local limestoneSlabId = registerBlock
        ("limestoneSlab", "Limestone Slab", "res/limestone_slab.png",
            BlockDefinition.new ({ shape = "slab", hardness = 4.0, resistance = 10.0, tool = EBlockTool.Pickaxe, sound = "stone" })
        )
    log("Pixel's Blocks: registered limestone slab as id " .. tostring(limestoneSlabId))

    local limestoneStairsId = registerBlock
        ("limestoneStairs", "Limestone Stairs", "res/limestone_slab.png",
            BlockDefinition.new ({ shape = "stairs", hardness = 4.0, resistance = 10.0, tool = EBlockTool.Pickaxe, sound = "stone" })
        )
    log("Pixel's Blocks: registered limestone stairs as id " .. tostring(limestoneStairsId))

    -- Marble

    local marbleId = registerBlock
        ("marble", "Marble", "res/marble.png", 
            BlockDefinition.new ({ hardness = 4.0, resistance = 10.0, tool = EBlockTool.Pickaxe, sound = "stone" })
        )
    log("Pixel's Blocks: registered marble as id " .. tostring(marbleId))

    local polishedMarbleId = registerBlock
        ("polishedMarble", "Polished Marble", "res/polished_marble.png",
            BlockDefinition.new ({ hardness = 4.0, resistance = 10.0, tool = EBlockTool.Pickaxe, sound = "stone" })
        )
    log("Pixel's Blocks: registered polished marble as id " .. tostring(polishedMarbleId))

    local marbleBricksId = registerBlock
        ("marbleBricks", "Marble Bricks", "res/marble_bricks.png",
            BlockDefinition.new ({ hardness = 4.0, resistance = 10.0, tool = EBlockTool.Pickaxe, sound = "stone" })
        )
    log("Pixel's Blocks: registered marble bricks as id " .. tostring(marbleBricksId))

    local marbleSlabId = registerBlock
        ("marbleSlab", "Marble Slab", "res/marble_slab.png",
            BlockDefinition.new ({ shape = "slab", hardness = 4.0, resistance = 10.0, tool = EBlockTool.Pickaxe, sound = "stone" })
        )
    log("Pixel's Blocks: registered marble slab as id " .. tostring(marbleSlabId))

    local marbleStairsId = registerBlock
        ("marbleStairs", "Marble Stairs", "res/marble_slab.png",
            BlockDefinition.new ({ shape = "stairs", hardness = 4.0, resistance = 10.0, tool = EBlockTool.Pickaxe, sound = "stone" })
        )
    log("Pixel's Blocks: registered marble stairs as id " .. tostring(marbleStairsId))

    -- Gneiss

    local gneissId = registerBlock
        ("gneiss", "Gneiss", "res/gneiss.png",
            BlockDefinition.new ({ hardness = 4.0, resistance = 10.0, tool = EBlockTool.Pickaxe, sound = "stone" })
        )
    log("Pixel's Blocks: registered gneiss as id " .. tostring(gneissId))

    local polishedGneissId = registerBlock
        ("polishedGneiss", "Polished Gneiss", "res/polished_gneiss.png",
            BlockDefinition.new ({ hardness = 4.0, resistance = 10.0, tool = EBlockTool.Pickaxe, sound = "stone" })
        )
    log("Pixel's Blocks: registered polished gneiss as id " .. tostring(polishedGneissId))

    local gneissBricksId = registerBlock
        ("gneissBricks", "Gneiss Bricks", "res/gneiss_bricks.png",
            BlockDefinition.new({ hardness = 4.0, resistance = 10.0, tool = EBlockTool.Pickaxe, sound = "stone" })
        )
    log("Pixel's Blocks: registered gneiss bricks as id " .. tostring(gneissBricksId))

    local gneissSlabId = registerBlock
        ("gneissSlab", "Gneiss Slab", "res/polished_gneiss.png",
            BlockDefinition.new ({ shape = "slab", hardness = 4.0, resistance = 10.0, tool = EBlockTool.Pickaxe, sound = "stone" })
        )
    log("Pixel's Blocks: registered gneiss slab as id " .. tostring(gneissSlabId))

    local gneissStairsId = registerBlock
        ("gneissStairs", "Gneiss Stairs", "res/polished_gneiss.png",
            BlockDefinition.new ({ shape = "stairs", hardness = 4.0, resistance = 10.0, tool = EBlockTool.Pickaxe, sound = "stone" })
        )
    log("Pixel's Blocks: registered gneiss stairs as id " .. tostring(gneissStairsId))

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------- RECIPES ---------------------------------------------------------------------------------------------------------------

    registerShapedRecipe
    (
        "lucidBlockRecipe", 
        { "BPB", "WWW", "BPB" },
        { B = "minecraft:light_blue_wool", W = "minecraft:white_wool", P = "minecraft:pink_wool" }, 
        "pixblocks:lucidBlock", 
        { count = 1, group = ERecipeGroup.Decoration }
    )

    -- Polished

    registerShapedRecipe
    (
        "polishedGraniteRecipe", { "   ", " GG", " GG" }, { G = "pixblocks:granite" }, "pixblocks:polishedGranite", { count = 4, group = ERecipeGroup.Structure }
    )

    registerShapedRecipe
    (
        "polishedLimestoneRecipe", { "   ", " LL", " LL" }, { L = "pixblocks:limestone" }, "pixblocks:polishedLimestone", { count = 4, group = ERecipeGroup.Structure }
    )

    registerShapedRecipe
    (
        "polishedMarbleRecipe", { "   ", " MM", " MM" }, { M = "pixblocks:marble" }, "pixblocks:polishedMarble", { count = 4, group = ERecipeGroup.Structure }
    )

    registerShapedRecipe
    (
        "polishedGneissRecipe", { "   ", " NN", " NN" }, { N = "pixblocks:gneiss" }, "pixblocks:polishedGneiss", { count = 4, group = ERecipeGroup.Structure }
    )

    -- Bricks

    registerShapedRecipe
    (
        "graniteBricksRecipe", { "   ", " GG", " GG" }, { G = "pixblocks:polishedGranite" }, "pixblocks:graniteBricks", { count = 4, group = ERecipeGroup.Structure }
    )
    
    registerShapedRecipe
    (
        "limestoneBricksRecipe", { "   ", " LL", " LL" }, { L = "pixblocks:polishedLimestone" }, "pixblocks:limestoneBricks", { count = 4, group = ERecipeGroup.Structure }
    )

    registerShapedRecipe
    (
        "marbleBricksRecipe", { "   ", " MM", " MM" }, { M = "pixblocks:polishedMarble" }, "pixblocks:marbleBricks", { count = 4, group = ERecipeGroup.Structure }
    )

    registerShapedRecipe
    (
        "gneissBricksRecipe", { "   ", " NN", " NN" }, { N = "pixblocks:polishedGneiss" }, "pixblocks:gneissBricks", { count = 4, group = ERecipeGroup.Structure }
    )

    -- Slabs

    registerShapedRecipe
    (
        "graniteSlabRecipe", { "GGG" }, { G = "pixblocks:polishedGranite"}, "pixblocks:graniteSlab", { count = 6, group = ERecipeGroup.Structure }
    )

    registerShapedRecipe
    (
        "limestoneSlabRecipe", { "LLL" }, { L = "pixblocks:polishedLimestone"}, "pixblocks:limestoneSlab", { count = 6, group = ERecipeGroup.Structure }
    )

    registerShapedRecipe
    (
        "marbleSlabRecipe", { "MMM" }, { M = "pixblocks:polishedMarble"}, "pixblocks:marbleSlab", { count = 6, group = ERecipeGroup.Structure }
    )

    registerShapedRecipe
    (
        "gneissSlabRecipe", { "NNN" }, { N = "pixblocks:polishedGneiss" }, "pixblocks:gneissSlab", { count = 6, group = ERecipeGroup.Structure }
    )

    -- Stairs

    registerShapedRecipe
    (
        "graniteStairsRecipe", { "  G", " GG", "GGG" }, { G = "pixblocks:polishedGranite"}, "pixblocks:graniteStairs", { count = 6, group = ERecipeGroup.Structure }
    )

    registerShapedRecipe
    (
        "limestoneStairsRecipe", { "  L", " LL", "LLL" }, { L = "pixblocks:polishedLimestone"}, "pixblocks:limestoneStairs", { count = 6, group = ERecipeGroup.Structure }
    )

    registerShapedRecipe
    (
        "marbleStairsRecipe", { "  M", " MM", "MMM" }, { M = "pixblocks:polishedMarble"}, "pixblocks:marbleStairs", { count = 6, group = ERecipeGroup.Structure }
    )
    
    registerShapedRecipe
    (
        "gneissStairsRecipe", { "  N", " NN", "NNN" }, { N = "pixblocks:polishedGneiss"}, "pixblocks:gneissStairs", { count = 6, group = ERecipeGroup.Structure }
    )

    --Smelting Recipes

    registerSmeltingRecipe("limestoneSmelt", "pixblocks:limestone", "pixblocks:marble", { count = 1, xp = 0.5 })

    registerSmeltingRecipe("graniteSmelt", "pixblocks:granite", "pixblocks:gneiss", { count = 1, xp = 0.5 })

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

end