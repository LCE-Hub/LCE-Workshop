function main()

    -- Blocks
    local lucidBlockId = registerBlock
        ("lucidBlock", "Lucid Block", "res/lucid_block.png",
            BlockDefinition.new
            ({
                hardness = 2.0,
                resistance = 10.0,
                tool = EBlockTool.None, --Actually, it's EBlockTool.None i think
                sound = "cloth"                 -- Turns out "wool" is not what its called, its called "cloth". This may or may not make the recipe show up.
            })
        )
    log("Pixel's Blocks: registered lucidBlock as id " .. tostring(lucidBlockId))

    local graniteId = registerBlock
        ("granite", "Granite", "res/granite.png",
            BlockDefinition.new
            ({
                hardness = 4.0,
                resistance = 10.0,
                tool = EBlockTool.Pickaxe,
                sound = "stone"
            })
        )
    log("Pixel's Blocks: registered granite as id " .. tostring(graniteId))

    local limestoneId = registerBlock
        ("limestone", "Limestone", "res/limestone.png",
            BlockDefinition.new
            ({
                hardness = 4.0,
                resistance = 10.0,
                tool = EBlockTool.Pickaxe,
                sound = "stone"
            })
        )
    log("Pixel's Blocks: registered limestone as id " .. tostring(limestoneId))

    local marbleId = registerBlock
        ("marble", "Marble", "res/marble.png",
            BlockDefinition.new
            ({
                hardness = 4.0,
                resistance = 10.0,
                tool = EBlockTool.Pickaxe,
                sound = "stone"
            })
        )
    log("Pixel's Blocks: registered marble as id " .. tostring(MarbleId))


    --Recipes
    registerShapedRecipe
    (
        "lucidBlockRecipe", { "BPB", "WWW", "BPB" },
        { B = "minecraft:light_blue_wool", W = "minecraft:white_wool", P = "minecraft:pink_wool" }, "pixblocks:lucidBlock", { count = 1, group = ERecipeGroup.Decoration }
    )

    registerSmeltingRecipe
    ("limestoneSmelt", "pixblocks:limestone", "pixblocks:marble", { count = 1, xp = 0.5 })

end