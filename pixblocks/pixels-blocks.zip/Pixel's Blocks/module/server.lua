-- Worldgen stuff is also done here
function main()
    registerEvent
	(	-- Fires on player join
		"PlayerJoinEvent", function(event)
        local player = event.player
        player:sendMessage("Pixel's Blocks active")
        log("Pixel's Blocks: " .. player.name .. " joined")
    	end
	)

    registerEvent
	(	-- Fires on block destroyed
		"PlayerBlockBreakEvent", function(event)
        log("Pixel's Blocks: " .. event.block.oid .. " broken at " .. tostring(event.block.pos))
    	end
    )

    -- Ores (well, not really "ores")
    registerOreFeature ( "graniteFeature", "pixblocks:granite", { size = 15, target = "minecraft:stone", dimension = 0, yMin = 20, yMax = 128, count = 10 } )
    registerOreFeature ( "limestoneFeature", "pixblocks:limestone", { size = 20, target = "minecraft:sandstone", dimension = 0, yMin = 20, yMax = 128, count = 10 } )
    registerOreFeature ("marbleFeature", "pixblocks:marble", { size = 20, target = "minecraft:stone", dimension = 0, yMin = 20, yMax = 128, count = 5 })

    --Add granite! Yeah mc already has granite, but my granite is not ugly and actually looks like granite!
    --Add limestone! You can find it in beaches or deserts!
    --Add marble! Its like quartz, but shinier!
    --Add sapphire rainbow block!

end