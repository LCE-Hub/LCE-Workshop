function main()

    -- Events
    registerEvent
	(
		"PlayerJoinEvent", function(event)
        local player = event.player
        log("Pixel's Blocks: " .. player.name .. " joined")
    	end
	)

    registerEvent
	(
		"PlayerBlockBreakEvent", function(event)
        log("Pixel's Blocks: " .. event.block.oid .. " broken at " .. tostring(event.block.pos))
    	end
    )

    -- Worldgen stuff
    registerOreFeature ( "graniteFeature", "pixblocks:granite", { size = 15, target = "minecraft:stone", dimension = 0, yMin = 20, yMax = 128, count = 20 } )
    registerOreFeature ( "limestoneFeature", "pixblocks:limestone", { size = 20, target = "minecraft:sandstone", dimension = 0, yMin = 20, yMax = 128, count = 20 } )
    registerOreFeature ("marbleFeature", "pixblocks:marble", { size = 5, target = "minecraft:stone", dimension = 0, yMin = 0, yMax = 20, count = 5 })
    registerOreFeature ("gneissFeature", "pixblocks:gneiss", { size = 10, target = "minecraft:stone", dimension = 0, yMin = 0, yMax = 20, count = 5})
    
end