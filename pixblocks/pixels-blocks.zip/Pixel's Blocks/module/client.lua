function main()

    log.info("Pixel's Blocks: client info message")
    log.warn("Pixel's Blocks: client warning message")
    log.error("Pixel's Blocks: client error message")

    --Do logs and stuff here. If there are any issues, just log everything to see what the issue could be.

end

-- Note to self: Do not mind the global definitions BS, its just the debug being stupid

-- Now that I have all 4 mineral classes done, this mod can now be released. I would like to do more with this mod, but at its current state it qualifies as finished.