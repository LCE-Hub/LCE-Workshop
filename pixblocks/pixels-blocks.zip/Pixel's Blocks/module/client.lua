function main()

    log.info("Pixel's Blocks: client info message")
    log.warn("Pixel's Blocks: client warning message")
    log.error("Pixel's Blocks: client error message")

    --Ill just do the stuff later

end

--HOW DO I GET THESE GLOBAL DEFINITIONS RAAAAH