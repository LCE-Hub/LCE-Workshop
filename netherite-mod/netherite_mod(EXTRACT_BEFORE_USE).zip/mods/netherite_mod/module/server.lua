function main()
    registerOreFeature
	(
		"ancientDebrisOre",
		"netherite_mod:ancientDebris",
		{
			size = 3,
			target = "minecraft:netherrack",
			dimension = -1,
			yMin = 8, yMax = 24,
			count = 1,
		}
	)

    registerOreFeature
	(
		"ancientDebrisOreAlt",
		"netherite_mod:ancientDebris",
		{
			size = 2,
			target = "minecraft:netherrack",
			dimension = -1,
			yMin = 8, yMax = 119,
			count = 1,
		}
	)

    registerOreFeature
	(
		"scrapNuggetOreFeature",
		"netherite_mod:scrapNuggetOre",
		{
			size = 5,
			target = "minecraft:stone",
			dimension = 0,
			yMin = 1, yMax = 15,
			count = 7,
		}
	)

end
