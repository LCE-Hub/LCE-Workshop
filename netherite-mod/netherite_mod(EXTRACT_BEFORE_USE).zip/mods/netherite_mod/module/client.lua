function main()
	--tiers
	local netheriteTier = registerItemTier
	(
		"netherite",
		{
			level = 4,
			uses = 2031,
			speed = 9,
			damage = 4,
			ench = 15
		}
	)

	local netheriteArmorMaterial = registerArmorMaterial
	(
		"netherite",
		{
			durabilityMultiplier = 37,
			head = 3,
			torso = 8,
			legs = 6,
			feet = 3,
			ench = 15
		}
	)

	--basic items
	local scrapNuggetId = registerItem
	(
		"scrapNugget", "Netherite Scrap Nugget", "res/item/scrap_nugget.png", 
		ItemDefinition.new
		(
			{
				base = EBaseItem.Default,
				material = EItemMaterial.Diamond
			}
		)
	)

	local netheriteScrapId = registerItem
	(
		"netheriteScrap", "Netherite Scrap", "res/item/netherite_scrap.png", 
		ItemDefinition.new
		(
			{
				base = EBaseItem.Ingot,
				material = EItemMaterial.Diamond
			}
		)
	)

	local netheriteUpgradeId = registerItem
	(
		"netheriteUpgrade", "Netherite Upgrade", "res/item/netherite_upgrade_smithing_template.png", 
		ItemDefinition.new
		(
			{
				base = EBaseItem.Ingot,
				material = EItemMaterial.Diamond
			}
		)
	)

	local netheriteIngotId = registerItem
	(
		"netheriteIngot", "Netherite Ingot", "res/item/netherite_ingot.png", 
		ItemDefinition.new
		(
			{
				base = EBaseItem.Ingot,
				material = EItemMaterial.Iron
			}
		)
	)

	--blocks
	local netheriteBlockId = registerBlock
	(
		"netheriteBlock", "Block of Netherite", "res/block/netherite_block.png",
		BlockDefinition.new
		(
			{
				hardness = 50.0,
				resistance = 1200.0,
				tool = EBlockTool.Pickaxe,
				sound = "metal"
			}
		)
	)

	local ancientDebrisId = registerBlock
	(
		"ancientDebris", "Ancient Debris", "res/block/ancient_debris_side.png",
		BlockDefinition.new
		(
			{
				hardness = 50.0,
				resistance = 1200.0,
				tool = EBlockTool.Pickaxe,
				sound = "metal",
				topTexture = "res/block/ancient_debris_top.png",
				bottomTexture = "res/block/ancient_debris_top.png"
			}
		)
	)

	local scrapNuggetOreId = registerBlock
	(
		"scrapNuggetOre", "Scrap Ore", "res/block/scrap_nugget_ore.png",
		BlockDefinition.new
		(
			{
				hardness = 3.5,
				resistance = 3.0,
				tool = EBlockTool.Pickaxe,
				sound = "stone",
			}
		)
	)

	--armor
	local netheriteHelmetId = registerItem
	(
		"netheriteHelmet", "Netherite Helmet", "res/item/netherite_helmet.png",
		ItemDefinition.new
		(
			{
				base = EBaseItem.Helmet, 
				armorSet = "netherite", 
				customArmorMaterial = netheriteArmorMaterial
			}
		)
	)

	local netheriteChestplateId = registerItem
	(
		"netheriteChestplate", "Netherite Chestplate", "res/item/netherite_chestplate.png", 
		ItemDefinition.new
		(
			{
				base = EBaseItem.Chestplate, 
				armorSet = "netherite", 
				customArmorMaterial = netheriteArmorMaterial
			}
		)
	)

	local netheriteLeggingsId = registerItem
	(
		"netheriteLeggings", "Netherite Leggings", "res/item/netherite_leggings.png", 
		ItemDefinition.new
		(
			{
				base = EBaseItem.Leggings, 
				armorSet = "netherite", 
				customArmorMaterial = netheriteArmorMaterial
			}
		)
	)

	local netheriteBootsId = registerItem
	(
		"netheriteBoots", "Netherite Boots", "res/item/netherite_boots.png", 
		ItemDefinition.new
		(
			{
				base = EBaseItem.Boots, 
				armorSet = "netherite", 
				customArmorMaterial = netheriteArmorMaterial
			}
		)
	)

	--tools
	local netheriteSwordId = registerItem
	(
		"netheriteSword", "Netherite Sword", "res/item/netherite_sword.png", 
		ItemDefinition.new
		(
			{
				base = EBaseItem.Weapon,
				customTier = netheriteTier,
				material = EItemMaterial.Diamond
			}
		)
	)
	
	local netheriteAxeId = registerItem
	(
		"netheriteAxe", "Netherite Axe", "res/item/netherite_axe.png", 
		ItemDefinition.new
		(
			{
				base = EBaseItem.Hatchet, 
				customTier = netheriteTier, 
				material = EItemMaterial.Diamond
			}
		)
	)
	
	local netheritePickaxeId = registerItem
	(
		"netheritePickaxe", "Netherite Pickaxe", "res/item/netherite_pickaxe.png", 
		ItemDefinition.new
		(
			{
				base = EBaseItem.Pickaxe, 
				customTier = netheriteTier, 
				material = EItemMaterial.Diamond
			}
		)
	)
	
	local netheriteShovelId = registerItem
	(
		"netheriteShovel", "Netherite Shovel", "res/item/netherite_shovel.png", 
		ItemDefinition.new
		(
			{
				base = EBaseItem.Shovel, 
				customTier = netheriteTier, 
				material = EItemMaterial.Diamond
			}
		)
	)
	
	local netheriteHoeId = registerItem
	(
		"netheriteHoe", "Netherite Hoe", "res/item/netherite_hoe.png", 
		ItemDefinition.new
		(
			{
				base = EBaseItem.Hoe, 
				customTier = netheriteTier, 
				material = EItemMaterial.Diamond
			}
		)
	)

	--recipes
	registerShapedRecipe
	(
		"netheriteUpgradeAlt",
		{
			"DRD",
			"DRD",
			"DDD"
		}, 
		{ D = "minecraft:diamond", R = "minecraft:netherrack" },
		"netherite_mod:netheriteUpgrade",
		{ count = 1, group = ERecipeGroup.Decoration }
	)

	registerShapedRecipe
	(
		"netheriteUpgrade",
		{
			"DTD",
			"DRD",
			"DDD"
		}, 
		{ D = "minecraft:diamond", R = "minecraft:netherrack", T = "netherite_mod:netheriteUpgrade" },
		"netherite_mod:netheriteUpgrade",
		{ count = 2, group = ERecipeGroup.Decoration }
	)

	registerShapedRecipe
	(
		"scrapNuggetToScrap",
		{
			"NNN",
			"NNN",
			"NNN"
		}, 
		{ N = "netherite_mod:scrapNugget" },
		"netherite_mod:netheriteScrap",
		{ count = 1, group = ERecipeGroup.Decoration }
	)

	registerSmeltingRecipe
	(
		"scrapNuggetOreSmelt",
		"netherite_mod:scrapNuggetOre",
		"netherite_mod:scrapNugget",
		{ count = 2, xp = 0.7 }
	)

	registerShapedRecipe
	(
		"netheriteScrapToIngot",
		{
			" SS",
			"SSG",
			"GGG"
		}, 
		{ S = "netherite_mod:netheriteScrap", G = "minecraft:gold_ingot" },
		"netherite_mod:netheriteIngot",
		{ count = 1, group = ERecipeGroup.Decoration }
	)

	registerShapedRecipe
	(
		"netheriteBlock",
		{
			"NNN",
			"NNN",
			"NNN"
		}, 
		{ N = "netherite_mod:netheriteIngot" },
		"netherite_mod:netheriteBlock",
		{ count = 1, group = ERecipeGroup.Decoration }
	)

	--armor recipes
	registerShapedRecipe
	(
		"netheriteHelmet",
		{
			"ATI",
			"   ",
			"   "
		}, 
		{ A = "minecraft:diamond_helmet", T = "netherite_mod:netheriteUpgrade", I = "netherite_mod:netheriteIngot" },
		"netherite_mod:netheriteHelmet",
		{ count = 1, group = ERecipeGroup.Armour }
	)

	registerShapedRecipe
	(
		"netheriteChestplate",
		{
			"ATI",
			"   ",
			"   "
		}, 
		{ A = "minecraft:diamond_chestplate", T = "netherite_mod:netheriteUpgrade", I = "netherite_mod:netheriteIngot" },
		"netherite_mod:netheriteChestplate",
		{ count = 1, group = ERecipeGroup.Armour }
	)

	registerShapedRecipe
	(
		"netheriteLeggings",
		{
			"ATI",
			"   ",
			"   "
		}, 
		{ A = "minecraft:diamond_leggings", T = "netherite_mod:netheriteUpgrade", I = "netherite_mod:netheriteIngot" },
		"netherite_mod:netheriteLeggings",
		{ count = 1, group = ERecipeGroup.Armour }
	)

	registerShapedRecipe
	(
		"netheriteBoots",
		{
			"ATI",
			"   ",
			"   "
		}, 
		{ A = "minecraft:diamond_boots", T = "netherite_mod:netheriteUpgrade", I = "netherite_mod:netheriteIngot" },
		"netherite_mod:netheriteBoots",
		{ count = 1, group = ERecipeGroup.Armour }
	)

	--tool recipes
	registerShapedRecipe
	(
		"netheriteSword",
		{
			"ATI",
			"   ",
			"   "
		}, 
		{ A = "minecraft:diamond_sword", T = "netherite_mod:netheriteUpgrade", I = "netherite_mod:netheriteIngot" },
		"netherite_mod:netheriteSword",
		{ count = 1, group = ERecipeGroup.Tool }
	)

	registerShapedRecipe
	(
		"netheriteAxe",
		{
			"ATI",
			"   ",
			"   "
		}, 
		{ A = "minecraft:diamond_axe", T = "netherite_mod:netheriteUpgrade", I = "netherite_mod:netheriteIngot" },
		"netherite_mod:netheriteAxe",
		{ count = 1, group = ERecipeGroup.Tool }
	)

	registerShapedRecipe
	(
		"netheritePickaxe",
		{
			"ATI",
			"   ",
			"   "
		}, 
		{ A = "minecraft:diamond_pickaxe", T = "netherite_mod:netheriteUpgrade", I = "netherite_mod:netheriteIngot" },
		"netherite_mod:netheritePickaxe",
		{ count = 1, group = ERecipeGroup.Tool }
	)

	registerShapedRecipe
	(
		"netheriteShovel",
		{
			"ATI",
			"   ",
			"   "
		}, 
		{ A = "minecraft:diamond_shovel", T = "netherite_mod:netheriteUpgrade", I = "netherite_mod:netheriteIngot" },
		"netherite_mod:netheriteShovel",
		{ count = 1, group = ERecipeGroup.Tool }
	)

	registerShapedRecipe
	(
		"netheriteHoe",
		{
			"ATI",
			"   ",
			"   "
		}, 
		{ A = "minecraft:diamond_hoe", T = "netherite_mod:netheriteUpgrade", I = "netherite_mod:netheriteIngot" },
		"netherite_mod:netheriteHoe",
		{ count = 1, group = ERecipeGroup.Tool }
	)
end
